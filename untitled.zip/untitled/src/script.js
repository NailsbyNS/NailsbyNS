function showPage(page) {
  document
    .querySelectorAll("section")
    .forEach((sec) => sec.classList.remove("active"));
  document.getElementById(page).classList.add("active");
}
